import React from 'react';
import { dogs } from './pets.MyPetFrom';
import Header from './header';

interface Dog {
  Code: string;
  Name: string;
  Photo: string;
  Birthdate: string;
  Category: string;
  Sex: string;
  Owner_Name: string;
  Owner_Email: string;
}

const MyPetList: React.FC = () => {
  return (
    <>
      <Header />
      <main>
        <div className="App" style={{ backgroundColor: 'white', color: 'black', padding: '20px' }}>
          <h1 style={{ color: 'black' }}>Dog Information</h1>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={{ border: '1px solid black', padding: '10px' }}>Photo</th>
                <th style={{ border: '1px solid black', padding: '10px' }}>Name</th>
                <th style={{ border: '1px solid black', padding: '10px' }}>Birthdate</th>
                <th style={{ border: '1px solid black', padding: '10px' }}>Category</th>
                <th style={{ border: '1px solid black', padding: '10px' }}>Sex</th>
                <th style={{ border: '1px solid black', padding: '10px' }}>Owner Name</th>
                <th style={{ border: '1px solid black', padding: '10px' }}>Owner Email</th>
              </tr>
            </thead>
            <tbody>
              {dogs.map((dog: Dog) => (
                <tr key={dog.Code}>
                  <td style={{ border: '1px solid black', padding: '10px' }}>
                    <img src={dog.Photo} alt={dog.Name} width="100" />
                  </td>
                  <td style={{ border: '1px solid black', padding: '10px' }}>{dog.Name}</td>
                  <td style={{ border: '1px solid black', padding: '10px' }}>{dog.Birthdate}</td>
                  <td style={{ border: '1px solid black', padding: '10px' }}>{dog.Category}</td>
                  <td style={{ border: '1px solid black', padding: '10px' }}>{dog.Sex}</td>
                  <td style={{ border: '1px solid black', padding: '10px' }}>{dog.Owner_Name}</td>
                  <td style={{ border: '1px solid black', padding: '10px' }}>{dog.Owner_Email}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </>
  );
};

export default MyPetList;
