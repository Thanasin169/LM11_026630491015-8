import React from 'react';
import Header from './header';
import Footer from './footer';

const App: React.FC = () => {
  return (
    <>
      <Header />
      <main>
       
      </main>
      <Footer />
    </>
  );
};

export default App;
